-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 23, 2019 at 05:16 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `newbakery`
--

-- --------------------------------------------------------

--
-- Table structure for table `addcarts`
--

CREATE TABLE `addcarts` (
  `cart_id` bigint(20) UNSIGNED NOT NULL,
  `id` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `totquantity` int(11) NOT NULL,
  `totalprice` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `addcarts`
--

INSERT INTO `addcarts` (`cart_id`, `id`, `pid`, `totquantity`, `totalprice`, `status`, `created_at`, `updated_at`) VALUES
(1, 31, 7, 2, 6000, 1, NULL, NULL),
(5, 42, 3, 2, 600, 1, NULL, NULL),
(6, 42, 7, 5, 15000, 1, NULL, NULL),
(8, 44, 16, 2, 400, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `additems`
--

CREATE TABLE `additems` (
  `item_id` int(10) UNSIGNED NOT NULL,
  `cat_id` int(10) UNSIGNED NOT NULL,
  `item` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `additems`
--

INSERT INTO `additems` (`item_id`, `cat_id`, `item`, `created_at`, `updated_at`) VALUES
(3, 1, 'Birthday Cake', '2019-04-01 01:05:56', '2019-04-01 01:05:56'),
(4, 1, 'Wedding Cake', '2019-04-01 01:08:48', '2019-04-01 01:08:48'),
(5, 1, 'Event Cake', '2019-04-01 01:35:19', '2019-04-01 01:35:19'),
(8, 3, 'Oreo', '2019-04-09 23:10:38', '2019-04-09 23:10:38'),
(9, 3, 'Goodday', '2019-04-09 23:14:00', '2019-04-09 23:14:00'),
(10, 3, 'Dark Fantasy', '2019-04-09 23:15:27', '2019-04-09 23:15:27'),
(11, 4, 'Jalebi', '2019-04-25 12:27:51', '2019-04-25 12:27:51'),
(12, 4, 'Gulam Jamun', '2019-04-25 12:28:16', '2019-04-25 12:28:16'),
(13, 6, 'vegetable puffs', '2019-04-29 22:52:46', '2019-04-29 22:52:46'),
(14, 6, 'chicken puffs', '2019-04-29 22:53:02', '2019-04-29 22:53:02'),
(15, 6, 'egg puffs', '2019-04-29 22:53:16', '2019-04-29 22:53:16');

-- --------------------------------------------------------

--
-- Table structure for table `addproducts`
--

CREATE TABLE `addproducts` (
  `pid` int(10) UNSIGNED NOT NULL,
  `cat_id` int(10) UNSIGNED NOT NULL,
  `item_id` int(10) UNSIGNED NOT NULL,
  `productname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` double(8,2) NOT NULL,
  `price` double(8,2) NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `addproducts`
--

INSERT INTO `addproducts` (`pid`, `cat_id`, `item_id`, `productname`, `image`, `quantity`, `price`, `description`, `created_at`, `updated_at`) VALUES
(3, 1, 3, 'Black Forest', '4.jfif', 30.00, 300.00, 'Black Forest Cake, German Chocolate Cake- It has 4 chocolatey layers,with strawberry.Maximum 3 hours to deliver product.', NULL, '2019-05-04 01:14:43'),
(7, 1, 4, 'white forest', 'wa.jpg', 2.00, 3000.00, 'White Forest Cake Cake Flavour: White Chocolate Type of Cake and above Shapes Available:', NULL, '2019-05-07 00:47:33'),
(10, 6, 13, 'Vegetable Puffs', 'p1.jpg', 30.00, 20.00, 'Vegetable Puff, a snack with crisp-n-flaky outer layer and mixed vegetables stuffing, is a quick and tasty way of satisfying urge of something savory.', NULL, NULL),
(14, 6, 15, 'Egg puffs', 'p3.png', 10.00, 20.00, 'Egg Waffles/Eggettes/Egg Puffs, are a Hong Kong street snack. The batter is sweet, resembling a pancake batter. When cooked in a special egg waffle iron, the area connecting the eggs puffs are crispy and the egg puffs themselves are light and fluffy', NULL, NULL),
(15, 6, 14, 'chicken puffs', 'p2.jpg', 30.00, 20.00, 'Chicken Puffs. \"A rich, creamy chicken sauce is rolled in croissants and baked to form delicious puffs. Wonderful for get togethers.', NULL, NULL),
(16, 4, 12, 'Gulam Jamun', '23.jpg', 20.00, 200.00, 'Gulab jamuns (translated very roughly as \'rose-fruits\') may have got their name from the fact that they are jamun (an Indian fruit) shaped, round, and usually soaked in a rosewater scented syrup.', NULL, NULL),
(17, 1, 3, 'Black Forest', 'a.jpg', 10.00, 1000.00, 'kkkkkk', NULL, NULL),
(18, 6, 14, 'chicken puffs', 'p1.jpg', 5.00, 678.00, 'hhhh', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `banks`
--

CREATE TABLE `banks` (
  `bankid` bigint(20) UNSIGNED NOT NULL,
  `id` int(11) NOT NULL,
  `bname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cardname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cardno` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cvv` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mon` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `year` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `banks`
--

INSERT INTO `banks` (`bankid`, `id`, `bname`, `cardname`, `cardno`, `cvv`, `mon`, `year`, `amount`, `created_at`, `updated_at`) VALUES
(1, 1, 'hdfc', 'bency', '1234567898765432', '001', 'jan', '2019', 48935, NULL, NULL),
(2, 2, 'sbt', 'kacheriyan', '9876543212345678', '201', 'feb', '2020', 1065, NULL, NULL),
(3, 31, 'hdfc', 'albin', '1234567898765432', '586', 'feb', '2021', 50000, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(10) UNSIGNED NOT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `category`, `created_at`, `updated_at`) VALUES
(1, 'Cake', NULL, NULL),
(2, 'Bread', NULL, NULL),
(3, 'Biscuits', NULL, NULL),
(4, 'Sweets', NULL, NULL),
(6, 'puffs', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `deliveries`
--

CREATE TABLE `deliveries` (
  `did` bigint(20) UNSIGNED NOT NULL,
  `id` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phoneno` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `landmark` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `town` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `deliveries`
--

INSERT INTO `deliveries` (`did`, `id`, `pid`, `email`, `firstname`, `phoneno`, `date`, `landmark`, `town`, `status`, `created_at`, `updated_at`) VALUES
(25, 31, 6, 'bencykulathinkal@gmail.com', 'Bency', '9745641514', '2019-05-22', 'Kerala', 'Palakkad', 1, NULL, NULL),
(26, 28, 17, 'jeebu@gmail.com', 'jeebu', '9745641514', '2019-05-24', 'Kerala', 'Palakkad', 1, NULL, NULL),
(27, 31, 7, 'bency1996kulathinkal@gmail.com', 'Bency', '9745641514', '2019-05-08', 'Kerala', 'Palakkad', 1, NULL, NULL),
(28, 31, 14, 'bency1996kulathinkal@gmail.com', 'Bency', '9745641514', '2019-05-08', 'Kerala', 'Palakkad', 1, NULL, NULL),
(29, 31, 7, 'bency1996kulathinkal@gmail.com', 'Bency', '9745641514', '2019-05-08', 'Kerala', 'Palakkad', 1, NULL, NULL),
(30, 31, 14, 'bency1996kulathinkal@gmail.com', 'Bency', '9745641514', '2019-05-08', 'Kerala', 'Palakkad', 1, NULL, NULL),
(31, 31, 16, 'bency1996kulathinkal@gmail.com', 'Bency', '9745641514', '2019-05-08', 'Kerala', 'Palakkad', 1, NULL, NULL),
(32, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-09', 'Kerala', 'Palakkad', 1, NULL, NULL),
(33, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-09', 'Kerala', 'Palakkad', 1, NULL, NULL),
(34, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-09', 'Kerala', 'Palakkad', 1, NULL, NULL),
(35, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(36, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(37, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(38, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(39, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(40, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(41, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(42, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(43, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(44, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(45, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(46, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(47, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(48, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(49, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(50, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(51, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(52, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(53, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(54, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(55, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(56, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(57, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(58, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(59, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(60, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(61, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(62, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(63, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(64, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(65, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(66, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(67, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(68, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(69, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(70, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(71, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(72, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(73, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(74, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-25', 'Kerala', 'Palakkad', 1, NULL, NULL),
(75, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-25', 'Kerala', 'Palakkad', 1, NULL, NULL),
(76, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-25', 'Kerala', 'Palakkad', 1, NULL, NULL),
(77, 28, 7, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-25', 'Kerala', 'Palakkad', 1, NULL, NULL),
(78, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-25', 'Kerala', 'Palakkad', 1, NULL, NULL),
(79, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-25', 'Kerala', 'Palakkad', 1, NULL, NULL),
(80, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-25', 'Kerala', 'Palakkad', 1, NULL, NULL),
(81, 28, 7, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-25', 'Kerala', 'Palakkad', 1, NULL, NULL),
(82, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-25', 'Kerala', 'Palakkad', 1, NULL, NULL),
(83, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-25', 'Kerala', 'Palakkad', 1, NULL, NULL),
(84, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-25', 'Kerala', 'Palakkad', 1, NULL, NULL),
(85, 28, 7, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-25', 'Kerala', 'Palakkad', 1, NULL, NULL),
(86, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-25', 'Kerala', 'Palakkad', 1, NULL, NULL),
(87, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-25', 'Kerala', 'Palakkad', 1, NULL, NULL),
(88, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-25', 'Kerala', 'Palakkad', 1, NULL, NULL),
(89, 28, 7, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-25', 'Kerala', 'Palakkad', 1, NULL, NULL),
(90, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'zxcvb', 'xcvbn', 1, NULL, NULL),
(91, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'zxcvb', 'xcvbn', 1, NULL, NULL),
(92, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'zxcvb', 'xcvbn', 1, NULL, NULL),
(93, 28, 7, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'zxcvb', 'xcvbn', 1, NULL, NULL),
(94, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(95, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(96, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(97, 28, 7, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(98, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(99, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(100, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(101, 28, 7, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(102, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(103, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(104, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(105, 28, 7, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(106, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(107, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(108, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(109, 28, 7, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(110, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(111, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(112, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(113, 28, 7, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(114, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(115, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(116, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(117, 28, 7, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(118, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(119, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(120, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(121, 28, 7, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(122, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(123, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(124, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(125, 28, 7, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(126, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(127, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(128, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(129, 28, 7, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(130, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(131, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(132, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(133, 28, 7, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(134, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(135, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(136, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(137, 28, 7, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(138, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(139, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(140, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(141, 28, 7, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-02-04', 'dcfvbn', 'cvbnm', 1, NULL, NULL),
(142, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-11', 'Kerala', 'Palakkad', 1, NULL, NULL),
(143, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-11', 'Kerala', 'Palakkad', 1, NULL, NULL),
(144, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-11', 'Kerala', 'Palakkad', 1, NULL, NULL),
(145, 28, 7, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-11', 'Kerala', 'Palakkad', 1, NULL, NULL),
(146, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(147, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(148, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(149, 28, 7, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(150, 28, 16, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(151, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(152, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(153, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(154, 28, 7, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(155, 28, 16, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(156, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(157, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(158, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(159, 28, 7, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(160, 28, 16, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(161, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-16', 'Kerala', 'Palakkad', 1, NULL, NULL),
(162, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-16', 'Kerala', 'Palakkad', 1, NULL, NULL),
(163, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-16', 'Kerala', 'Palakkad', 1, NULL, NULL),
(164, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(165, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(166, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(167, 28, 14, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(168, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(169, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(170, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(171, 28, 14, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(172, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(173, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(174, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(175, 28, 14, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(176, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(177, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(178, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(179, 28, 14, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(180, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(181, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(182, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(183, 28, 14, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(184, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(185, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(186, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(187, 28, 14, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(188, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(189, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(190, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(191, 28, 14, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(192, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(193, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(194, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(195, 28, 14, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(196, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(197, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(198, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(199, 28, 14, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(200, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(201, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(202, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(203, 28, 14, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(204, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(205, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(206, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(207, 28, 14, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(208, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(209, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(210, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(211, 28, 14, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(212, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(213, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(214, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(215, 28, 14, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(216, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(217, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(218, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(219, 28, 14, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(220, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(221, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(222, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(223, 28, 14, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-10', 'Kerala', 'Palakkad', 1, NULL, NULL),
(224, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-11', 'Kerala', 'Palakkad', 1, NULL, NULL),
(225, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-11', 'Kerala', 'Palakkad', 1, NULL, NULL),
(226, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-11', 'Kerala', 'Palakkad', 1, NULL, NULL),
(227, 28, 14, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-11', 'Kerala', 'Palakkad', 1, NULL, NULL),
(228, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-11', 'Kerala', 'Palakkad', 1, NULL, NULL),
(229, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-11', 'Kerala', 'Palakkad', 1, NULL, NULL),
(230, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-11', 'Kerala', 'Palakkad', 1, NULL, NULL),
(231, 28, 14, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-11', 'Kerala', 'Palakkad', 1, NULL, NULL),
(232, 28, 17, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-11', 'Kerala', 'Palakkad', 1, NULL, NULL),
(233, 28, 10, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-11', 'Kerala', 'Palakkad', 1, NULL, NULL),
(234, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-11', 'Kerala', 'Palakkad', 1, NULL, NULL),
(235, 28, 14, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-11', 'Kerala', 'Palakkad', 1, NULL, NULL),
(236, 28, 17, 'jeebu@gmail.com', 'tessa', '9745641514', '2019-05-14', 'Kerala', 'Palakkad', 1, NULL, NULL),
(237, 28, 10, 'jeebu@gmail.com', 'tessa', '9745641514', '2019-05-14', 'Kerala', 'Palakkad', 1, NULL, NULL),
(238, 28, 3, 'jeebu@gmail.com', 'tessa', '9745641514', '2019-05-14', 'Kerala', 'Palakkad', 1, NULL, NULL),
(239, 42, 10, 'albincheriyan@gmail.com', 'Bency', '9745641514', '2019-05-16', 'Kerala', 'Palakkad', 1, NULL, NULL),
(240, 42, 10, 'albincheriyan@gmail.com', 'Bency', '9745641514', '2019-05-16', 'Kerala', 'Palakkad', 1, NULL, NULL),
(241, 42, 10, 'albincheriyan@gmail.com', 'Bency', '9745641514', '2019-05-16', 'Kerala', 'Palakkad', 1, NULL, NULL),
(242, 42, 10, 'albincheriyan@gmail.com', 'Bency', '9745641514', '2019-05-16', 'Kerala', 'Palakkad', 1, NULL, NULL),
(243, 42, 10, 'albincheriyan@gmail.com', 'Bency', '9745641514', '2019-05-16', 'Kerala', 'Palakkad', 1, NULL, NULL),
(244, 42, 10, 'albincheriyan@gmail.com', 'Bency', '9745641514', '2019-05-16', 'Kerala', 'Palakkad', 1, NULL, NULL),
(245, 42, 10, 'albincheriyan@gmail.com', 'Lakshmipriya', '9745641514', '2019-05-17', 'Kerala', 'Palakkad', 1, NULL, NULL),
(246, 42, 14, 'albincheriyan@gmail.com', 'Lakshmipriya', '9745641514', '2019-05-17', 'Kerala', 'Palakkad', 1, NULL, NULL),
(247, 42, 10, 'albincheriyan@gmail.com', 'Bency', '9745641514', '2019-05-17', 'Kerala', 'Palakkad', 1, NULL, NULL),
(248, 42, 14, 'albincheriyan@gmail.com', 'Bency', '9745641514', '2019-05-17', 'Kerala', 'Palakkad', 1, NULL, NULL),
(249, 28, 3, 'jeebu@gmail.com', 'Bency', '9745641514', '2019-05-17', 'Kerala', 'Palakkad', 1, NULL, NULL),
(250, 42, 3, 'albincheriyan@gmail.com', 'Albin', '9876543212', '2019-05-07', 'tyyytttttt', 'Palakkad', 1, NULL, NULL),
(251, 42, 3, 'albincheriyan@gmail.com', 'Bency', '9745641514', '2019-05-18', 'Kerala', 'Palakkad', 1, NULL, NULL),
(252, 42, 7, 'albincheriyan@gmail.com', 'Bency', '9745641514', '2019-05-18', 'Kerala', 'Palakkad', 1, NULL, NULL),
(253, 44, 16, 'albincheriyan@gmail.com', 'Albin', '9745641514', '2019-06-15', 'Kerala', 'Palakkad', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `logins`
--

CREATE TABLE `logins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(10) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `logins`
--

INSERT INTO `logins` (`id`, `email`, `password`, `type`, `status`, `created_at`, `updated_at`) VALUES
(2, 'admin@gmail.com', 'admin', '0', 0, NULL, NULL),
(26, 'divya@gmail.com', 'divya', '1', 0, NULL, '2019-04-28 09:55:20'),
(27, 'delvin@gmail.com', 'delvin', '1', 0, NULL, '2019-04-29 05:14:05'),
(28, 'jeebu@gmail.com', 'jeebu', '1', 0, NULL, NULL),
(29, 'anson@gmail.com', 'anson', '1', 0, NULL, NULL),
(30, 'merin@gmail.com', 'merin', '1', 0, NULL, NULL),
(31, 'bency1996kulathinkal@gmail.com', 'bency', '1', 0, NULL, NULL),
(32, 'anandhu@gmail.com', 'anandhu', '1', 0, NULL, NULL),
(33, 'arunthomas15011995@gmail.com', 'arun', '1', 1, NULL, '2019-05-06 10:49:52'),
(34, 'anju@gmail.com', 'anju', '1', 1, NULL, '2019-05-06 10:48:35'),
(35, 'chippy@gmail.com', 'chippy', '1', 1, NULL, '2019-04-29 22:29:51'),
(36, 'aaa@gmail.com', 'a', '1', 1, NULL, '2019-05-06 10:48:27'),
(37, 'gopika@gmail.com', 'gopika', '1', 1, NULL, '2019-05-06 03:50:39'),
(39, 'sruthi@gmail.com', 'sruthi', '1', 0, NULL, NULL),
(40, 'uuuu@gmail.com', 'uuuu', '1', 1, NULL, '2019-05-15 11:49:57'),
(41, 'jinu@gmail.com', 'jinu', '1', 0, NULL, NULL),
(42, 'albincheriyan@gmail.com', 'albincheriyan', '1', 0, NULL, NULL),
(43, 'alan@gmail.com', 'alan', '1', NULL, NULL, NULL),
(44, 'albincheriyan@gmail.com', 'albin', '1', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2019_03_10_164831_create_registers_table', 1),
(2, '2019_03_11_034721_create_logins_table', 2),
(5, '2019_03_15_044730_create_districts_table', 3),
(7, '2019_03_15_151736_create_places_table', 4),
(13, '2019_03_28_150118_create_categories_table', 9),
(14, '2019_03_28_164750_create_additems_table', 10),
(20, '2019_04_02_035731_create_addproducts_table', 13),
(21, '2019_04_27_154608_create_details_table', 14),
(22, '2019_05_02_090055_create_recipies_table', 15),
(27, '2019_05_03_044615_create_deliveries_table', 16),
(29, '2019_04_26_170014_create_addcarts_table', 18),
(31, '2019_05_04_070405_create_payments_table', 19),
(32, '2019_05_10_060140_create_banks_table', 20);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('bencykulathinkal@gmail.com', '$2y$10$yUAxIlQU.gSyuGymEm469.3QYGCAlRbLtvhq7ibTSS7XztAUtcpcu', '2019-04-28 13:51:40');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payid` bigint(20) UNSIGNED NOT NULL,
  `id` int(11) NOT NULL,
  `bname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cardname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cardno` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cvv` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mon` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `year` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payid`, `id`, `bname`, `cardname`, `cardno`, `cvv`, `mon`, `year`, `amount`, `created_at`, `updated_at`) VALUES
(1, 28, 'hdfc', 'bency', '1234567898765432', '001', 'Jan', '2019', 700, NULL, NULL),
(2, 28, 'hdfc', 'bency', '1234567898765432', '001', 'Jan', '2019', 700, NULL, NULL),
(3, 28, 'hdfc', 'bency', '1234567898765432', '001', 'Jan', '2019', 700, NULL, NULL),
(4, 28, 'hdfc', 'bency', '1234567898765432', '001', 'Jan', '2019', 700, NULL, NULL),
(5, 42, 'hdfc', 'bency', '1234567898765432', '001', 'Jan', '2019', 40, NULL, NULL),
(6, 42, 'hdfc', 'bency', '1234567898765432', '001', 'Jan', '2019', 40, NULL, NULL),
(7, 42, 'hdfc', 'bency', '1234567898765432', '001', 'Jan', '2019', 40, NULL, NULL),
(8, 42, 'hdfc', 'bency', '1234567898765432', '001', 'Jan', '2019', 40, NULL, NULL),
(9, 42, 'hdfc', 'bency', '1234567898765432', '001', 'Jan', '2019', 40, NULL, NULL),
(10, 42, 'hdfc', 'bency', '1234567898765432', '001', 'Jan', '2019', 40, NULL, NULL),
(11, 42, 'hdfc', 'bency', '1234567898765432', '001', 'Jan', '2019', 40, NULL, NULL),
(12, 42, 'hdfc', 'bency', '1234567898765432', '001', 'Jan', '2019', 80, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `recipies`
--

CREATE TABLE `recipies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `proname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `upload` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `recipies`
--

INSERT INTO `recipies` (`id`, `proname`, `upload`, `created_at`, `updated_at`) VALUES
(1, 'bhgjhgh', '1556790812_MCA_Regular_Fifth_To_Sixth_Semester_Syllabus_final-07_06_2017.pdf', '2019-05-02 04:23:32', '2019-05-02 04:23:32'),
(2, 'ertyuii', '1556790837_db.txt', '2019-05-02 04:23:57', '2019-05-02 04:23:57'),
(4, 'black forest', '1557134943_a.jpg', '2019-05-06 03:59:03', '2019-05-06 03:59:03');

-- --------------------------------------------------------

--
-- Table structure for table `registers`
--

CREATE TABLE `registers` (
  `regid` bigint(20) UNSIGNED NOT NULL,
  `firstname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phoneno` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `registers`
--

INSERT INTO `registers` (`regid`, `firstname`, `lastname`, `phoneno`, `email`, `password`, `type`, `status`, `created_at`, `updated_at`) VALUES
(41, 'Divya', 'John', '9874563217', 'divya@gmail.com', 'divya', '1', 'registerd', NULL, NULL),
(42, 'Delvin', 'Antony', '9856471234', 'delvin@gmail.com', 'delvin', '1', 'registerd', NULL, NULL),
(43, 'jeebu', 'reji', '9745642589', 'jeebu@gmail.com', 'jeebu', '1', 'registerd', NULL, NULL),
(44, 'Anson', 'Antony', '9856231478', 'anson@gmail.com', 'anson', '1', 'registerd', NULL, NULL),
(45, 'merin', 'mm', '9785124578', 'merin@gmail.com', 'merin', '1', 'registerd', NULL, NULL),
(47, 'Bency', 'Cheriyan', '9745641514', 'bency1996kulathinkal@gmail.com', 'bency', '1', 'registerd', NULL, NULL),
(48, 'anandhu', 'subash', '9153572584', 'anandhu@gmail.com', 'anandhu', '1', 'registerd', NULL, NULL),
(49, 'Arun', 'Thomas', '9544103818', 'arunthomas15011995@gmail.com', 'arun', '1', 'registerd', NULL, NULL),
(50, 'anju', 'Thomas', '9548712365', 'anju@gmail.com', 'anju', '1', 'registerd', NULL, NULL),
(51, 'chippy', 'a', '9231786542', 'chippy@gmail.com', 'chippy', '1', 'registerd', NULL, NULL),
(52, 'ccccc', 'aaa', '7894561237', 'aaa@gmail.com', 'a', '1', 'registerd', NULL, NULL),
(53, 'gopika', 'vijayan', '9745641514', 'gopika@gmail.com', 'gopika', '1', 'registerd', NULL, NULL),
(55, 'sruthi', 'sruthii', '9745641514', 'sruthi@gmail.com', 'sruthi', '1', 'registerd', NULL, NULL),
(56, 'fgdgdf', 'gfdgdg', '9745641514', 'uuuu@gmail.com', 'uuuu', '1', 'registerd', NULL, NULL),
(57, 'jinu', 'reji', '9745641514', 'jinu@gmail.com', 'jinu', '1', 'registerd', NULL, NULL),
(58, 'Albin', 'Cheriyan', '9745641514', 'albincheriyan@gmail.com', 'albincheriyan', '1', 'registerd', NULL, NULL),
(59, 'Alan', 'Jose', '9539835630', 'alan@gmail.com', 'alan', '1', 'registerd', NULL, NULL),
(60, 'Albin', 'Cheriyan', '9495068214', 'albincheriyan@gmail.com', 'albin', '1', 'registerd', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addcarts`
--
ALTER TABLE `addcarts`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `additems`
--
ALTER TABLE `additems`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `additems_cat_id_foreign` (`cat_id`);

--
-- Indexes for table `addproducts`
--
ALTER TABLE `addproducts`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `addproducts_cat_id_foreign` (`cat_id`),
  ADD KEY `addproducts_item_id_foreign` (`item_id`);

--
-- Indexes for table `banks`
--
ALTER TABLE `banks`
  ADD PRIMARY KEY (`bankid`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `deliveries`
--
ALTER TABLE `deliveries`
  ADD PRIMARY KEY (`did`);

--
-- Indexes for table `logins`
--
ALTER TABLE `logins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payid`);

--
-- Indexes for table `recipies`
--
ALTER TABLE `recipies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registers`
--
ALTER TABLE `registers`
  ADD PRIMARY KEY (`regid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addcarts`
--
ALTER TABLE `addcarts`
  MODIFY `cart_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `additems`
--
ALTER TABLE `additems`
  MODIFY `item_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `addproducts`
--
ALTER TABLE `addproducts`
  MODIFY `pid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `banks`
--
ALTER TABLE `banks`
  MODIFY `bankid` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `deliveries`
--
ALTER TABLE `deliveries`
  MODIFY `did` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=254;

--
-- AUTO_INCREMENT for table `logins`
--
ALTER TABLE `logins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payid` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `recipies`
--
ALTER TABLE `recipies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `registers`
--
ALTER TABLE `registers`
  MODIFY `regid` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `additems`
--
ALTER TABLE `additems`
  ADD CONSTRAINT `additems_cat_id_foreign` FOREIGN KEY (`cat_id`) REFERENCES `categories` (`cat_id`);

--
-- Constraints for table `addproducts`
--
ALTER TABLE `addproducts`
  ADD CONSTRAINT `addproducts_cat_id_foreign` FOREIGN KEY (`cat_id`) REFERENCES `categories` (`cat_id`),
  ADD CONSTRAINT `addproducts_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `additems` (`item_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
