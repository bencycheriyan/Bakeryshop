<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});



Route::get('/index','indexController@index');

Route::get('/about','aboutController@about');

Route::post('/login','loginController@store');

Route::any('/Loginme','loginController@Userlogin');

Route::get('/blockunblock{{id}}','LoginController@blockunblock');

Route::get('/nregister','indexController@nregister');

Route::get('/nlogin','indexController@nlogin');

Route::post('/sregister','RegisterController@store');

Route::get('admin.adminindex','adminController@adminindex');

Route::get('customer.cusindex','customerController@cusindex');

Route::get('customer.about','customerController@about');

Route::get('customer.checkout','customerController@checkout');

Route::get('customer.shop','AddproductController@viewitemcus');


Route::get('/logout','loginController@logout');


Route::get('/customer.profile','RegisterController@viewprofile');



Route::get('/allcustomer','RegisterController@index');


Route::get('/addcategory','adminController@addcategory');
Route::any('/addcat','CategoryController@store');




Route::any('/additem','AdditemController@store');
Route::get('/customerindex','AdditemController@customerindex');
Route::any('/itemadd','AdditemController@additem');


Route::get('/addproduct','AddproductController@index');
Route::any('/ajax/{id}','AddproductController@ajax');
Route::any('/productadd1','AddproductController@store');
Route::get('/viewproduct','AddproductController@viewproduct');
Route::get('/admin.editproduct','adminController@editproduct');
Route::resource('/user','AddproductController');





// Route::get('/search1','AddproductController@search1');

// Route::get('/customer.search1','customerController@search1');

Route::get('/customer.single', function () {
    return view('customer.single');
});
//Route::get('/customer.single','customerController@single');
Route::any('/customer.single','AddproductController@single');


//Route::any('/customer.checkout','AddcartController@checkout');
//Route::any('/customer.check','AddcartController@checkout');
Route::any('/delete-product','AddcartController@destroy');
Route::any('/checkoutt','AddcartController@addtocart');

Route::any('block{id}','LoginController@blockuser')->name('block');

Route::get('customer.payment','customerController@payment');
Route::any('/pay','PaymentController@store');


Route::get('customer.recipie','customerController@recipie');
Route::get('/addrecipie','adminController@addrecipie');
Route::any('/addrep','recipieController@store');


Route::get('customer.delivery','customerController@delivery');
Route::any('del','DeliveryController@store');


//Route::get('customer.blocked','adminController@blocked');

Route::get('/category','CategoryController@index');
Route::get('/item','AdditemController@index');
Route::get('/blocked','AdditemController@indexxx');
Route::get('/bookdetails','DeliveryController@bookdetail');

Route::get('/sucess','indexController@sucess');

Route::get('customer.details','DeliveryController@cusdetail');

Route::get('/sucesses','customerController@sucesses');



Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
