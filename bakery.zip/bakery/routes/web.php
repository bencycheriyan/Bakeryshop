<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});

Route::get('/index','indexController@index');

Route::get('/about','aboutController@about');

Route::post('/login','loginController@store');

Route::any('/Loginme','loginController@Userlogin');

Route::get('/register','indexController@register');

Route::get('/login','indexController@login');

Route::post('/register','RegisterController@store');

Route::get('admin.adminindex','adminController@adminindex');

Route::get('customer.customerindex','customerController@customerindex');

Route::get('shopowner.shopownerindex','shopownerController@shopownerindex');

Route::get('/logout','loginController@logout');

Route::get('/shopowner.addproduct','shopownerController@addproduct');

Route::get('/shopowner.addshopdetails','shopownerController@addshopdetails');

Route::get('/shopowner.shopownerprofile','RegisterController@viewprofile');

Route::get('/allshopowner','RegisterController@indexer');

Route::get('/allcustomer','RegisterController@index');

Route::post('/adddistrict','DistrictController@store');

Route::get('/adddistrict','adminController@adddistrict');

Route::get('/addplace','adminController@addplace');

//Route::post('/shopowner.editprofile/{email}','shopownerController@editprofile');
//Route::get('/edit','RegisterController@change');
//Route::post('shopowner.editprofile/{email}','RegisterController@change')->name('shopowner.editprofile');









// Route::get('/shopownerreg','indexController@shopownerreg');
// Route::get('/distributorreg','indexController@distributorreg');

