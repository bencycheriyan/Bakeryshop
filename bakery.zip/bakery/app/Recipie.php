<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Recipie extends Model
{
    public $fillable=['proname','upload'];
}
