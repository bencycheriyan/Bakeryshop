<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Addcart extends Model
{
	protected $table='addcarts';
    public $fillable=['id','pid','totquantity','totalprice','status'];
}
