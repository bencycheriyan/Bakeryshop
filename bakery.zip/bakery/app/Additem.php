<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Additem extends Model
{
    public $fillable=['cat_id','item'];
}
