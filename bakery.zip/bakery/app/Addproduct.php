<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Addproduct extends Model
{
    //
}
