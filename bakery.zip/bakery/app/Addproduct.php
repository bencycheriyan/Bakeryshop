<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Addproduct extends Model
{
	protected $primarykey='pid';
	    public $fillable=['cat_id','item_id','productname','image','quantity','price','description'];
}
