<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bank extends Model
{
    public $fillable=['id','bname','cardname','cardno','cvv','mon','year','amount'];
}
