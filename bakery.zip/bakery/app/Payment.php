<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    public $fillable=['id','bname','cardname','cardno','cvv','mon','year','amount'];
}

