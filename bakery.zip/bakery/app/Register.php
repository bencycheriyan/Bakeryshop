<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Register extends Model
{
    public $fillable=['firstname','lastname','phoneno','email','password','type','status'];
}
