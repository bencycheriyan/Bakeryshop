<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Delivery extends Model
{
    public $fillable=['id','pid','email','firstname','phoneno','date','landmark','town','status'];
}
