<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class customerController extends Controller
{
    public function customerindex()
    {
    	return view('customer.customerindex');
    }
}
