<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class customerController extends Controller
{
    public function cusindex()
    {
    	return view('customer.cusindex');
    }
    public function about()
    {
        return view('customer.about');
    }
    public function shop()
    {
        return view('customer.shop');
    }
    public function profile()
    {
    	return view('customer.profile');
    }
    public function search1()
    {
    	return view('customer.search1');
    }
    public function single()
    {
        return view('customer.single');
    }
    public function checkout()
    {
        return view('customer.checkout');
    }
    public function payment()
    {
        return view('customer.payment');
    }
    public function recipie()
    {
        return view('customer.recipie');
    }
    public function delivery()
    {
        return view('customer.delivery');
    }
    public function details()
    {
        return view('customer.details');
    }
    public function sucesses()
    {
        return view('customer.sucesses');
    }
    
}
