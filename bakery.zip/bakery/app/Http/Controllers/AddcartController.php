<?php

namespace App\Http\Controllers;

use App\Addcart;
use Illuminate\Http\Request;
use DB;

class AddcartController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function addtocart(Request $re)
    {
        $a=session()->get('email');
        $x=DB::select("select * from logins where email='$a'");
        
        foreach ($x as $x) 
        {
            $userid=$x->id;
        }
        //return $userid;
        $unm=$re->input('pid');
        //return $unm;
        // echo ;
        // $check=DB::table('carts')->where(['p_id'=>$unm] and ['id'=>$userid])->get();
        $check=DB::select("select * from addcarts where pid='$unm' and id='$userid'");
        if(count($check)==0)
        {
     
     
        // $p_id=$re->input('p_id'); 
    
        $totquantity=$re->input('totquantity');
        //return $totquantity;
        $totalprice=$re->input('totalprice');
        $s=$totalprice*$totquantity;
        //return $s;
     
        DB::insert('insert into addcarts(cart_id,id,pid,totquantity,totalprice,status) 
        values(?,?,?,?,?,?)',[null,$userid,$unm,$totquantity,$s,1]);

        // $c=DB::select("select * from addcarts where  id='$userid'");

    
        return view('customer.checkout',compact('userid'))->with('alert', 'Product added to cart');
        }
        else
          {
             return view('customer.checkout')->with('alert', 'Already Exists in Cart');
          }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $re)
    {
        //$a=session()->get('email');
        $x=DB::select("select * from addcarts ");
        
        foreach ($x as $x) 
        {
            $cartid=$x->cart_id;
        }
        //$unm=$re->input('pid');
        
        DB::delete("delete from addcarts where cart_id='$cartid'");
        return redirect('customer.checkout');
    }



    public function showcheckout(Request $re,$id)
    {
      // $n=count($st);
       return view('customer.checkout');
    }
    public function checkout()
    {
      // $n=count($st);
        return view('customer.checkout');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Addcart  $addcart
     * @return \Illuminate\Http\Response
     */
    public function show(Addcart $addcart)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Addcart  $addcart
     * @return \Illuminate\Http\Response
     */
    public function edit(Addcart $addcart)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Addcart  $addcart
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Addcart $addcart)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Addcart  $addcart
     * @return \Illuminate\Http\Response
     */
    public function destroys(Addcart $addcart)
    {
        //
    }
}
