<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class indexController extends Controller
{
    public function index()
    {
    	return view('index');
    }
    public function nregister()
    {
    	return view('nregister');
    }
    public function nlogin()
    {
    	return view('nlogin');
    }
    public function sucess()
    {
        return view('sucess');
    }

}
    
