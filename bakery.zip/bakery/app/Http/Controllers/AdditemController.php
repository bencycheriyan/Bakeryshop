<?php

namespace App\Http\Controllers;

use App\Additem;
use App\Category;
use Illuminate\Http\Request;
use DB;
//Illuminate\Database\Query\Builder::innerjoin;

class AdditemController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $a=DB::table('additems')
        ->join('categories','categories.cat_id','=','additems.cat_id')
        //->join('additems','additems.cat_id','=','categories.cat_id')
         ->select('categories.*','additems.*')->get();
        return view('admin.item',compact('a'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function indexxx()
    {
        $customer=DB::table('registers')
        ->join('logins','registers.email','=','logins.email')
        ->select('registers.*','logins.*')
        ->where('logins.status','=',1)
        ->get();
        return view('admin.blocked',['custom'=>$customer]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
,=>request     */
    public function store(Request $request)
    {

          $item=DB::table('categories')->get();
          return view('admin.additem',['request'=>$item]); 
          
    }


     public function additem(Request $request)
    {
        request()->validate([
        'item'=>'unique:additems']);

        $aditem=new Additem(['cat_id'=>$request->input('category'),
         'item'=>$request->input('item')]);
          $aditem->save();
       return redirect('/additem');
    }
         
    /**
     * Display the specified resource.
     *
     * @param  \App\Additem  $additem
     * @return \Illuminate\Http\Response
     */
    public function show(Additem $additem)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Additem  $additem
     * @return \Illuminate\Http\Response
     */
    public function edit(Additem $additem)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Additem  $additem
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Additem $additem)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Additem  $additem
     * @return \Illuminate\Http\Response
     */
    public function destroy(Additem $additem)
    {
        //
    }
}
