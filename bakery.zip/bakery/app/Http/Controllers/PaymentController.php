<?php

namespace App\Http\Controllers;

use App\Payment;
use Illuminate\Http\Request;
use DB;

class PaymentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
           
         $a=session()->get('email');
        $x=DB::select("select * from logins where email='$a'");
        //return $x;
        foreach ($x as $x) 
        {
            $userid=$x->id;
        }
         

         //DB::select("select * from addcarts");
         
        //$s=$totalprice*$totquantity;
        



        $bname= $request->get('bname');
       //return $bname;
        $cardname= $request->get('cardname');
        //return $cardname;
        $cardno= $request->get('cardno');
      //return $cardno;
        $cvv= $request->get('cvv');
       //return $cvv;
        $mon= $request->get('mon');
       //return $mon;
        $year= $request->get('year');
      // return $year;
        $amount= $request->get('amount');
       // return $amount;

        $b=DB::table('banks')
        ->where('bname' ,'=', $bname)
        ->where('cardname' ,'=', $cardname)
        ->where('cardno', '=', $cardno)
        ->where('cvv', '=', $cvv)
        ->where('mon', '=', $mon)
        ->where('year', '=', $year)
        ->get();
        //return $b;


       if(count($b) == 0){
        //return "wrong";
            //return redirect()->back()->with('message','incorrect');;
       }
       else{

        $amount1=DB::select('select amount from banks where cardno = ?',[$cardno]);
        $amount2=DB::select('select amount from banks where cardno = ?',['9876543212345678']);
        ///return $amount1;
        // $note_id=DB::select('select note_id from notes where ');

        if($amount1[0]->amount > $amount){
            $rem=$amount1[0]->amount-$amount;

        $data=array('id'=>$userid,'bname'=>$bname,'cardname'=>$cardname,'cardno'=>$cardno,'cvv'=>$cvv,'mon'=>$mon,'year'=>$year,'amount'=>$amount);
            DB::table('payments')->insert($data);
            //'bankid' => 0,
            //'paytype' => 0,
       // return  $data;
    //$pay = $request->get('note_id');

        //$payment->save();
        $balance=$amount1[0]->amount-$amount;
        $adminbalance=$amount2[0]->amount+$amount;
        DB::update('update banks set amount = ? where cardno = ?',[$balance,$cardno]);
        DB::update('update banks set amount = ? where cardno = ?',[$adminbalance,'9876543212345678']);
       // return $request->get('note')
       //return $pay;

       //$nn= Notes::select('note')->where('note_id', $pay)->get();
       //return $nn;
       //return redirect('/downloadnote',compact('nn'));

        return view('customer.sucesses');

        }
        else{
            return redirect()->back()->with('message','no balance');

        }
       }


       return redirect('/sucesses');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        
    }
    

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function edit(Payment $payment)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Payment $payment)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function destroy(Payment $payment)
    {
        //
    }
}
