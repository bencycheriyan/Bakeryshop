<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class shopownerController extends Controller
{
     public function shopownerindex()
    {
    	return view('shopowner.shopownerindex');
    }
     public function addproduct()
    {
    	return view('shopowner.addproduct');
    }
    public function shopownerprofile()
    {
    	return view('shopowner.shopownerprofile');
    }
    public function addshopdetails()
    {
        return view('shopowner.addshopdetails');
    }
    public function editprofile()
    {
        return view('shopowner.editprofile');
    }

}
