<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class adminController extends Controller
{
    public function adminindex()
    {
    	return view('admin.adminindex');
    }
     public function allcustomer()
    {
    	return View('admin.allcustomer');
    }
     public function allshopowner()
    {
    	return View('admin.allshopowner');
    }
     public function adddistrict()
    {
    	return View('admin.adddistrict');
    }
     public function addplace()
    {
    	return View('admin.addplace');
    }
}
