<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class adminController extends Controller
{
    public function adminindex()
    {
    	return view('admin.adminindex');
    }
     public function allcustomer()
    {
    	return View('admin.allcustomer');
    }
     public function allshopowner()
    {
    	return View('admin.allshopowner');
    }
     public function addcategory()
    {
    	return View('admin.addcategory');
    }
     public function additem()
    {
    	return View('admin.additem');
    }
    public function addproduct()
    {
        return View('admin.addproduct');
    }
    public function viewproduct()
    {
        return View('admin.viewproduct');
    }
    public function editproduct()
    {
        return View('admin.editproduct');
    }
    public function addrecipie()
    {
        return View('admin.addrecipie');
    }
    public function category()
    {
        return View('admin.category');
    }
    public function item()
    {
        return View('admin.item');
    }
    public function blocked()
    {
        return View('admin.blocked');
    }
    public function bookdetails()
    {
        return View('admin.bookdetails');
    }

}
