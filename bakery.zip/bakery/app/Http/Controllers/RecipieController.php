<?php

namespace App\Http\Controllers;

use App\Recipie;
use Illuminate\Http\Request;
use DB;

class RecipieController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $proname = $request->input('proname');

        $files=$request->file('upload');
        $img=time().'_'.$files->getClientOriginalName();
        $imgs=$files->move(public_path().'/file/',$img);

        $upload=new Recipie(['proname'=>$proname,'upload'=>$img]);
        $upload->save();
        return redirect('/addrecipie');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Recipie  $recipie
     * @return \Illuminate\Http\Response
     */
    public function show(Recipie $recipie)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Recipie  $recipie
     * @return \Illuminate\Http\Response
     */
    public function edit(Recipie $recipie)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Recipie  $recipie
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Recipie $recipie)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Recipie  $recipie
     * @return \Illuminate\Http\Response
     */
    public function destroy(Recipie $recipie)
    {
        //
    }
}
