<?php

namespace App\Http\Controllers;

use App\Register;
use Illuminate\Http\Request;
use App\Login;
//use Crypt;
use DB;

class RegisterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $customer=Register::select('firstname','lastname','phoneno','email')->where('type','1')->get();
         //return view ('admin.allcustomer',compact('customer'));
        return view('admin.allcustomer',compact('customer'));
    }

public function indexer()
    {
        $shopowner=Register::select('firstname','lastname','phoneno','email')->where('type','2')->get();
        //return view ('admin.allcustomer',compact('customer'));
        return view('admin.allshopowner',compact('shopowner'));
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
    $utype = $request->input('utype');
    $firstname = $request->input('firstname');
    $lastname = $request->input('lastname');
    $phoneno = $request->input('phoneno');
    $email = $request->input('email');
    $password = $request->input('password');
    //$reg_id=$request->input('reg_id');
   
    //$u_type=$request->get('u_type');
    if($utype=='customer')
    {
        $status='registerd';
        $type=1;
  $data=array('firstname'=>$firstname,'lastname'=>$lastname,'phoneno'=>$phoneno,'email'=>$email,'password'=>$password,'type'=>$type,'status'=>$status);
DB::table('registers')->insert($data);
    }
   else if($utype=='shopowner')
    {
        $status='registerd';
        $type=2;
  $data=array('firstname'=>$firstname,'lastname'=>$lastname,'phoneno'=>$phoneno,'email'=>$email,'password'=>$password,'type'=>$type,'status'=>$status);
DB::table('registers')->insert($data);
    }
    else
    {
        $status='registerd';
        $type=3;
  $data=array('firstname'=>$firstname,'lastname'=>$lastname,'phoneno'=>$phoneno,'email'=>$email,'password'=>$password,'type'=>$type,'status'=>$status);
DB::table('registers')->insert($data);

    }
    if($utype=='customer')
        {
            $type=1;
            $data2=array('email'=>$email,'password'=>$password,'type'=>$type);
            DB::table('logins')->insert($data2);
        }
       else if($utype=='shopowner')
        {
            $type=2;
            $data2=array('email'=>$email,'password'=>$password,'type'=>$type);
            DB::table('logins')->insert($data2);
        }
        else
        {
            $type=3;
            $data2=array('email'=>$email,'password'=>$password,'type'=>$type);
            DB::table('logins')->insert($data2);
        }
       
    return redirect('/index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function show(Register $register)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */

    public function viewprofile()
    {
       if(session()->has('email'))
       {
         $x=session()->get('email');
       }
        //return $x;
         $result=Register::where('email','=',$x)->get();
       return view('shopowner.shopownerprofile',compact('result'));
    
    }

    public function edit(Register $register)
    {
        //
    }
    public function change($email)
    {
        $value = DB::table('registers')->where(['email'=>$email])->get();
        // foreach($car as $object)
        // {
        return view("shopowner.editprofile",compact('value'));
        //}
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$email)
    {
       $firstname = $request->input('firstname');
       $lastname=$request->input('lastname');
       $phoneno = $request->input('phoneno');
       $email = $request->input('email');

       $id=db::table('registers')->where('email',"=",$email)->get();
        
            
    $data=array("firstname"=>$firstname,"lastname"=>$lastname,"phoneno"=>$phoneno,"email"=>$email);
     DB::table('registers')->where('email',"=",$email)->update($data);
        
        return redirect("shopowner.shopownerprofile");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function destroy(Register $register)
    {
        //
    }
}
