<?php

namespace App\Http\Controllers;

use App\Register;
use Illuminate\Http\Request;
use App\Login;
//use Crypt;
use DB;
use Hash;

class RegisterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $customer=DB::table('registers')
        ->join('logins','registers.email','=','logins.email')
        ->select('registers.*','logins.*')
        ->where('logins.status','=',0)
        ->get();
        return view('admin.allcustomer',['custom'=>$customer]);
        // $customer=Register::select('firstname','lastname','phoneno','email')->where('type','1')->get();

        // $cus=Login::select('email','lastname','phoneno','email')->where('type','1')->get();
         //return view ('admin.allcustomer',compact('customer'));
        // return view('admin.allcustomer',compact('customer'));
    }

    // public function indexer()
    // {
    //     $shopowner=Register::select('firstname','lastname','phoneno','email')->where('type','2')->get();
    
    //     return view('admin.allshopowner',compact('shopowner'));
    // }


// public function indexxx()
//     {
//         $customer=DB::table('registers')
//         ->join('logins','registers.email','=','logins.email')
//         ->select('registers.*','logins.*')
//         ->where('logins.status','=',1)
//         ->get();
//         return view('admin.blockcustomer',['custom'=>$customer]);
//     }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
    $utype = $request->input('utype');
    $firstname = $request->input('firstname');
    $lastname = $request->input('lastname');
    $phoneno = $request->input('phoneno');
    $email = $request->input('email');
    // $password = Hash::make($request->input('password'));
    $password = $request->input('password');
    
        $status='registerd';
        $type=1;
        $data=array('firstname'=>$firstname,'lastname'=>$lastname,'phoneno'=>$phoneno,'email'=>$email,'password'=>$password,'type'=>$type,'status'=>$status);
        DB::table('registers')->insert($data);
    

            $type=1;
            $data2=array('email'=>$email,'password'=>$password,'type'=>$type);
            DB::table('logins')->insert($data2);
        
       
    return redirect('/sucess');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function show(Register $register)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */

    public function viewprofile()
    {
       if(session()->has('email'))
       {
         $x=session()->get('email');
       }
        //return $x;
         $result=Register::where('email','=',$x)->get();
       return view('customer.profile',compact('result'));
    
    }

    public function edit(Register $register)
    {
        //
    }
    // public function change($email)
    // {
    //     $value = DB::table('registers')->where(['email'=>$email])->get();
    //     return view("shopowner.editprofile",compact('value'));
        
    // }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    // public function update(Request $request,$email)
    // {
    //    $firstname = $request->input('firstname');
    //    $lastname=$request->input('lastname');
    //    $phoneno = $request->input('phoneno');
    //    $email = $request->input('email');

    //    $id=db::table('registers')->where('email',"=",$email)->get();
        
            
    // $data=array("firstname"=>$firstname,"lastname"=>$lastname,"phoneno"=>$phoneno,"email"=>$email);
    //  DB::table('registers')->where('email',"=",$email)->update($data);
        
    //     return redirect("shopowner.shopownerprofile");
    // }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function destroy(Register $register)
    {
        //
    }
}
