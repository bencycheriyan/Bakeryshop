<?php

namespace App\Http\Controllers;

use App\Addproduct;
use Illuminate\Http\Request;

class AddproductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Addproduct  $addproduct
     * @return \Illuminate\Http\Response
     */
    public function show(Addproduct $addproduct)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Addproduct  $addproduct
     * @return \Illuminate\Http\Response
     */
    public function edit(Addproduct $addproduct)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Addproduct  $addproduct
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Addproduct $addproduct)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Addproduct  $addproduct
     * @return \Illuminate\Http\Response
     */
    public function destroy(Addproduct $addproduct)
    {
        //
    }
}
