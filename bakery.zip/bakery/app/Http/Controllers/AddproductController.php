<?php

namespace App\Http\Controllers;

use App\Addproduct;
use App\Additem;
use App\Category;
use Illuminate\Http\Request;
use DB;

class AddproductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //$cat = DB::table('tbl_cat')->get(); 
        $category = DB::table('categories')->get(); 
        $item = DB::table('additems')->get();  
        return view('admin.addproduct',['category' => $category ],['item' => $item ]);
    }



    public function ajax($id)
    {
        // $subcat = DB::table("tbl_subcat")->where("cat_id",$id)->pluck("catagory","Cat_id");
        // return $cat = Addproduct::where("cat_id",$id)->get()->toJson();
        $cat = DB::select("select * from additems where cat_id = '$id'");
        return $cat;
    }

    public function itemajax($id)
    {
        // $subcat = DB::table("tbl_subcat")->where("cat_id",$id)->pluck("catagory","Cat_id");
        $it = Additem::where("item_id",$id)->get()->toJson();
        return $it;
    }


public function viewproduct()
    {
        $a=DB::table('addproducts')
        ->join('categories','categories.cat_id','=','addproducts.cat_id')
        ->join('additems','addproducts.item_id','=','additems.item_id')
        ->select('categories.*','additems.*','addproducts.*')->get();
        return view('admin.viewproduct',compact('a'));
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
            $cat_id=$request->input('category');
            $item_id=$request->input('item');
            $productname=$request->input('productname');
            $image=$request->input('image');
            $filename= $request->image->getClientOriginalName();
            $request->image->storeAs('public/upload',$filename);
            $quantity=$request->input('quantity');
            $price=$request->input('price');
            $description=$request->input('description');
    
            $data=array('cat_id'=>$cat_id,'item_id'=>$item_id,'productname'=>$productname,'image'=>$filename,'quantity'=>$quantity,'price'=>$price,'description'=>$description);
            DB::table('addproducts')->insert($data);
            
            //$adpro->save();
            return redirect('/addproduct');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Addproduct  $addproduct
     * @return \Illuminate\Http\Response
     */
    public function show(Addproduct $addproduct)
    {
        //
    }


    public function viewitemcus()
    {
        $a=DB::table('addproducts')
        ->join('categories','categories.cat_id','=','addproducts.cat_id')
        ->join('additems','addproducts.item_id','=','additems.item_id')
        ->select('categories.*','additems.*','addproducts.*')->get();
        return view('customer.shop',compact('a'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Addproduct  $addproduct
     * @return \Illuminate\Http\Response
     */
    public function edit($pid)
    {
        
        $newp=$pid;
        $p=DB::table('addproducts')
        ->select('addproducts.*')
        ->where('addproducts.pid','=',$newp)
        ->get();
        //return $pp;
        return view('admin.editproduct',compact('p'));
        
    }



    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Addproduct  $addproduct
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $pid)
    {
          // $productname = $request->input('productname');
          // $image=$request->input('image');
          // $filename= $request->image->getClientOriginalName();
          // $request->image->storeAs('public/upload',$filename);
          $quantity = $request->input('quantity');
          $price = $request->input('price');
          $description = $request->input('description');
          
          // return $pro=Addproduct::find($pid);

          // $pro->image=$filename;
          // $pro->price=$request->get('price');
          // $pro->description=$request->get('description');
          // $pro->save();

          Addproduct::where('pid', $pid)
          ->update([
             'quantity'=>$request->get('quantity'),
            'price'=>$request->get('price'),
             'description'=>$request->get('description')]);

          return redirect('viewproduct');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Addproduct  $addproduct
     * @return \Illuminate\Http\Response
     */
    public function destroy(Addproduct $addproduct)
    {
        //
    }
    public function customerindex()
    {
        return view('customer.customerindex');
    }


    public function search1(Request $req)
    {
       $search=$req->input('search');
       $product=DB::select("select * from additems where item='$search'");
       return view('customer.search1',compact('product'));

     }

     public function single(Request $request)
     {
        $id=$request->pid;
        $a=DB::select('select * from addproducts where pid='.$id.' ');
        return view('customer.single',['a'=>$a]);
     }
}




