<?php

namespace App\Http\Controllers;

use App\Delivery;
use Illuminate\Http\Request;
use DB;

class DeliveryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function bookdetail()
    {
        $a=DB::table('addcarts')
        ->join('logins','logins.id','=','addcarts.id')
        ->join('addproducts','addproducts.pid','=','addcarts.pid')
         ->select('logins.*','addcarts.*','addproducts.*')->get();
         //return $a;
        return view('admin.bookdetails',compact('a'));
    }

    public function cusdetail()
    {
        $a=DB::table('addcarts')
        ->join('logins','logins.id','=','addcarts.id')
        ->join('addproducts','addproducts.pid','=','addcarts.pid')
         ->select('logins.*','addcarts.*','addproducts.*')->get();
         //return $a;
        return view('customer.details');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
           $unm = session()->get('email');
         $d=DB::select("select id from logins where email='$unm'");
         foreach($d as $v)
         {
           $t=$v->id;
         //echo $t;
         $c=DB::select("select * from addcarts where id='$t'") ;  
         }       
       foreach($c as $s)
        {
            $sn=$s->pid;
           // return $s;
            //$un=$s->p_id;
             
            // echo $sn;  



            $email=$request->input('email');
            $firstname=$request->input('firstname');
            $phoneno=$request->input('phoneno');
            $date=$request->input('date');
            $landmark=$request->input('landmark');
            $town=$request->input('town');
            //$status=$->input('status');

        $data=array('id'=>$t,'pid'=>$sn,'email'=>$email,'firstname'=>$firstname,'phoneno'=>$phoneno,'date'=>$date,'landmark'=>$landmark,'town'=>$town,'status'=>1);
            DB::table('deliveries')->insert($data);
            }
            //$data->save();
        return view('/customer.payment');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Delivery  $delivery
     * @return \Illuminate\Http\Response
     */
    public function show(Delivery $delivery)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Delivery  $delivery
     * @return \Illuminate\Http\Response
     */
    public function edit(Delivery $delivery)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Delivery  $delivery
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Delivery $delivery)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Delivery  $delivery
     * @return \Illuminate\Http\Response
     */
    public function destroy(Delivery $delivery)
    {
        //
    }
}
