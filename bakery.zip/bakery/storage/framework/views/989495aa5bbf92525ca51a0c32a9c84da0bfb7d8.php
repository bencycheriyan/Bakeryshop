<?php /* E:\Laravel\bakery\resources\views/sucess.blade.php */ ?>
<!DOCTYPE html>
<html>
<head>
	<title>sucess</title>
    <style>
        a{
            font size: 5px; 
        }
    </style>
</head>
<body>
<br><br><br><br>
<div style="background-color: #978C8C;width: 900px;height: 200px;border: 2px solid white;padding-left: 10px;margin: 300px;margin-top:40px;padding-right: 10px">
        <br><br>
     <h1 align="center"><b><font color="#fff">Registration Completed Sucessfully</font></b></h1>
     <div align="center" >
     <a href="/nlogin">Login Now</a>
     </div>
 </div>
</body>
</html>