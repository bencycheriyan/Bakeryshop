<?php /* E:\Laravel\bakery\resources\views/admin/adminindex.blade.php */ ?>
<!--A Design by W3layouts
  Author: W3layout
  Author URL: http://w3layouts.com
  License: Creative Commons Attribution 3.0 Unported
  License URL: http://creativecommons.org/licenses/by/3.0/
  -->
  <?php if(session()->has('email')): ?>
<!DOCTYPE html>
<html lang="zxx">

<head>
  <title>Bakery</title>
  <!--meta tags -->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="keywords" content="Gateau Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
      Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
  <script>
    addEventListener("load", function () {
      setTimeout(hideURLbar, 0);
    }, false);

    function hideURLbar() {
      window.scrollTo(0, 1);
    }
  </script>
  <!--//meta tags ends here-->
  <!--booststrap-->
  <link href="admin/css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
  <!--//booststrap end-->
  <!-- font-awesome icons -->
  <link href="admin/css/font-awesome.min.css" rel="stylesheet">
  <!-- //font-awesome icons -->
  <!--stylesheets-->
  <link href="admin/css/style.css" rel='stylesheet' type='text/css' media="all">
  <!--//stylesheets-->
  <link href="//admin/fonts.googleapis.com/css?family=Arimo:400,700" rel="stylesheet">
  <link href="//admin/fonts.googleapis.com/css?family=Roboto:400,500,700,900" rel="stylesheet">
</head>

<body>
  <div class="main-top" id="home">
    <div class="headder-top">
      <!-- nav -->
      <nav>
        <div id="logo">
          <h1>
              <a href="adminindex">Bakery</a>
          </h1>
          <h6><?php echo e(session()->get('email')); ?></h6>
         
        </div>
        <label for="drop" class="toggle">Menu</label>
        <input type="checkbox" id="drop">
        <ul class="menu mt-2">
          
          <li class="active">
            <a href="admin.adminindex">Home</a>
          </li>
          <!-- <li class="mx-lg-3 mx-md-2 my-md-0 my-1">
            <a href="about.html">About</a>
          </li>
          <li>
            <a href="service.html">Services</a>
          </li> -->
          <li class="mx-lg-3 mx-md-2 my-md-0 my-1">
            <!-- First Tier Drop Down -->
            <label for="drop-2" class="toggle toogle-2">Pages
              <span class="fa fa-angle-down" aria-hidden="true"></span>
            </label>
             <a href="#">Pages
              <span class="fa fa-angle-down" aria-hidden="true"></span>
            </a>
            <input type="checkbox" id="drop-2">
            <ul>
              <li>
                <a href="/allcustomer" class="drop-text">Customers</a>
              </li>
              <!-- <li>
                <a href="/blockcustomer" class="drop-text">Blocked Customers</a>
              </li> -->
              <li>
                <a href="/addcategory" class="drop-text">Add Category</a>
              </li>
              <li>
                <a href="/additem" class="drop-text">Add Subcategory</a>
              </li>
              <li>
                <a href="/addproduct" class="drop-text">Add Product</a>
              </li>
              <li>
                <a href="/viewproduct" class="drop-text">view Product</a>
              </li>
              <!-- <li>
                <a href="/addrecipie" class="drop-text">Add Recipie</a>
              </li> -->
              
            </ul>
          </li>
        </li>

  <!-- </li> -->
    <li class="mx-lg-3 mx-md-2 my-md-0 my-1">

        <label for="drop-2" class="toggle toogle-2">Views
              <span class="fa fa-angle-down" aria-hidden="true"></span>
        </label>
                 <a href="#">Views
                 <span class="fa fa-angle-down" aria-hidden="true"></span>
                 </a>
                 <input type="checkbox" id="drop-2">
            <ul>
               <li>
                <a href="/category" class="drop-text">Category</a>
              </li>
              <li>
                <a href="/item" class="drop-text">SubCategory</a>
              </li>
              <!-- <li>
                <a href="/blocked" class="drop-text">Blocked Users</a>
              </li> -->
              <li>
                <a href="/bookdetails" class="drop-text">Booking History</a>
              </li>
              
            </ul>
    </li>
  <!-- </li> -->

           <li>
            <a href="/logout">Logout</a>
          </li> 
        </ul>
      </nav>
      <!-- //nav -->
    </div>
    <!-- banner -->
    <div class="container">
      <div class="row main-banner">
        <div class="col-lg-4 col-md-5 style-banner ">
          <div class="banner-rotated">
            <h4>
              <span> B</span>
            </h4>
            <h4>
              <span> a</span>
            </h4>
            <h4>
              <span> k</span>
            </h4>
            <h4>
              <span> e</span>
            </h4>
            <h4>
              <span> r</span>
            </h4>
            <h4>
              <span> y</span>
            </h4>
          </div>
          <!-- <div class="banner-rotated">
            <h4>
              <span> C</span>
            </h4>
            <h4>
              <span> a</span>
            </h4>
            <h4>
              <span> k</span>
            </h4>
            <h4>
              <span> e</span>
            </h4>
            <h4>
              <span> s</span>
            </h4>
          </div> -->
          <h5 class="mt-lg-4 mt-3">Delicious sweets for Your Special Event
          </h5>
        </div>
        <div class="col-lg-8 col-md-7 banner-imgs text-center">
          <div class="row no-gutters">
            <div class="col-sm-4 banner-right-images">
              <img src="admin/images/images.jpg" alt="news image" class="img-fluid">
            </div>
            <div class="col-sm-4 banner-right-images">
              <img src="admin/images/55.jpg" alt="news image" class="img-fluid">
            </div>
            <div class="col-sm-4 banner-right-images">
              <img src="admin/images/44.jpg" alt="news image" class="img-fluid">
            </div>
            
            <div class="col-sm-4 banner-right-images">
              <img src="admin/images/11.jpg" alt="news image" class="img-fluid">
            </div>
            <!-- <div class="col-sm-4 banner-right-images">
              <img src="admin/images/bb5.jpg" alt="news image" class="img-fluid ">
            </div> -->
            <div class="col-sm-4 banner-right-images">
              <img src="admin/images/bb1.jpg" alt="news image" class="img-fluid ">
            </div>
            
            <div class="col-sm-4 banner-right-images">
              <img src="admin/images/22.jpg" alt="news image" class="img-fluid">
            </div>
             <div class="col-sm-4 banner-right-images">
              <img src="admin/images/33.jpg" alt="news image" class="img-fluid">
            </div>
            <div class="col-sm-4 banner-right-images">
              <img src="admin/images/download.jpg" alt="news image" class="img-fluid">
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- //banner -->
  <!-- about -->
  <section class="about py-lg-4 py-md-3 py-sm-3 py-3" id="about">
    <div class="container py-lg-5 py-md-4 py-sm-4 py-3">
      <div class="row">
        <div class="col-lg-3 col-md-6 col-sm-6 about-two-grids my-3">
          <span class="fa fa-bars mb-3" aria-hidden="true"></span>
          <h4>Recipes</h4>
          <div class="about-para-txt mt-2">
            <p>A recipe is a set of instructions that describes how to prepare or make something, especially a culinary dish.</p>
          </div>
          <div class="view-buttn mt-md-4 mt-3">
            <a href="single.html" class="btn">Read More </a>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 about-two-grids my-3">
          <span class="fa fa-diamond mb-3" aria-hidden="true"></span>
          <h4>Products</h4>
          <div class="about-para-txt mt-2">
            <p>A bakery (also baker's shop or bake shop) is an establishment that produces and sells flour-based food baked in an oven such as bread, cookies, cakes,</p>
          </div>
          <div class="view-buttn mt-md-4 mt-3">
            <a href="single.html" class="btn">Read More </a>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 about-two-grids my-3">
          <span class="fa fa-birthday-cake mb-3" aria-hidden="true"></span>
          <h4>Cake Classes</h4>
          <div class="about-para-txt mt-2">
            <p>Cake is a form of sweet dessert that is typically baked. Typical cake ingredients are flour, sugar, eggs, butter</p>
          </div>
          <div class="view-buttn mt-md-4 mt-3">
            <a href="single.html" class="btn">Read More </a>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 title-right-side my-3">
          <div class="rotated-title">
            <h3 class="title mb-lg-4 mb-md-3 mb-2"> About</h3>
            <h6 class="title-sub">who are we</h6>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- //about -->
  <!-- service -->
  <section class="service py-lg-4 py-md-3 py-sm-3 py-3" id="service">
    <div class="container py-lg-5 py-md-4 py-sm-4 py-3">
      <div class="row">
        <div class="col-lg-3 col-md-4 my-3">
          <div class="rotated-title">
            <h3 class="title mb-lg-4 mb-md-3 mb-2">Service</h3>
            <h6 class="title-sub">What We dO</h6>
          </div>
        </div>
        <div class="col-lg-9 col-md-8 service-grid-top position-relative my-3">
          <img src="admin/images/bb1.jpg" alt="news image" class="img-fluid">
          <div class="ser-fashion-grid ser-fashion-wthree">
            <div class="about-icon mb-md-4 mb-3">
              <span class="fa fa-snowflake-o" aria-hidden="true"></span>
            </div>
            <div class="ser-sevice-grid">
              <h4 class="pb-3">Party Order</h4>
              <p>A bakery (also baker's shop or bake shop) is an establishment that produces and sells flour-based food baked in an oven such as bread, cookies, cakes, pastries, and pies. Some retail bakeries are also cafés, serving coffee and tea to customers who wish to consume the baked goods on the premises
              </p>
            </div>
          </div>
        </div>
      </div>
      <div class="row mid-row-grids">
        <div class="col-lg-3 col-md-6 col-sm-6 service-grid-wthree my-3">
          <div class="ser-fashion-wthree">
            <div class="about-icon mb-md-4 mb-3">
              <span class="fa fa-thumbs-o-up" aria-hidden="true"></span>
            </div>
            <div class="ser-sevice-grid">
              <h4 class="pb-3">Best Service</h4>
              <p>A bakery (also baker's shop or bake shop) is an establishment that produces and sells flour-based food baked in an oven such as bread, cookies, cakes, pastries, and pies. Some retail bakeries are also cafés, serving coffee and tea to customers who wish to consume the baked goods on the premises</p>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 service-grid-wthree my-3">
          <div class="ser-fashion-wthree">
            <div class="about-icon mb-md-4 mb-3">
              <span class="fa fa-laptop" aria-hidden="true"></span>
            </div>
            <div class="ser-sevice-grid">
              <h4 class="pb-3">Online Order</h4>
              <p>A bakery (also baker's shop or bake shop) is an establishment that produces and sells flour-based food baked in an oven such as bread, cookies, cakes, pastries, and pies. Some retail bakeries are also cafés, serving coffee and tea to customers who wish to consume the baked goods on the premises</p>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 service-grid-wthree my-3">
          <div class="ser-fashion-wthree">
            <div class="about-icon mb-md-4 mb-3">
              <span class="fa fa-smile-o" aria-hidden="true"></span>
            </div>
            <div class="ser-sevice-grid">
              <h4 class="pb-3">Door Delivery</h4>
              <p>A bakery (also baker's shop or bake shop) is an establishment that produces and sells flour-based food baked in an oven such as bread, cookies, cakes, pastries, and pies. Some retail bakeries are also cafés, serving coffee and tea to customers who wish to consume the baked goods on the premises</p>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 service-grid-wthree my-3">
          <div class="ser-fashion-wthree">
            <div class="about-icon mb-md-4 mb-3">
              <span class="fa fa-users" aria-hidden="true"></span>
            </div>
            <div class="ser-sevice-grid">
              <h4 class="pb-3">Event Catering</h4>
              <p>A bakery (also baker's shop or bake shop) is an establishment that produces and sells flour-based food baked in an oven such as bread, cookies, cakes, pastries, and pies. Some retail bakeries are also cafés, serving coffee and tea to customers who wish to consume the baked goods on the premises</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- //service -->
  <!-- Online Order -->
  <!-- <section class="advertise-count">
    <div class="container py-lg-5 py-md-4 py-sm-4 py-3">
      <div class="row">
        <div class="col-lg-6 col-md-6 fashion-collet-txt text-center">
          <h5>Online Order</h5>
          <h6 class="mt-lg-4 mt-3"> Get 25%/off</h6>
          <p class="mt-2">sed do eiusmod tempor incididunt ut Lorem ipsum dolor sit amet sit amet, eiusmod tempor incididunt ut labore et
            consectetur adipiscing sed do eiusmod</p>
        </div>
        <div class="col-lg-6 col-md-6 text-center">
          <div class="order-show-w3ls">
            <h5> Order Now</h5>

            <ul class="mt-lg-4 mt-3">
              <li>
                <p>
                  <span>Call</span> +123 4567 890</p>
              </li>
              <li class="mt-lg-3 mt-2">
                <p>
                  <span> Email</span> +123 4567 890</p>
              </li>
            </ul>
            <div class="order-buttn mt-lg-4 mt-3">
              <a href="contact.html" class="btn">Order Now </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section> -->
  <!--//Online Order -->
  <!-- menu -->
  <section class="collection py-lg-4 py-md-3 py-sm-3 py-3">
    <div class="container py-lg-5 py-md-4 py-sm-4 py-3">
      <!--row -->
      <div class="row">
        <div class="col-lg-5 col-md-5 collection-w3layouts my-3">
          <h4>Birthday Cake</h4>
          <p class="mt-2">A birthday cake is a cake eaten as part of a birthday celebration in many world traditions. Variations of the typical birthday cake include birthday cupcakes, cake pops, pastries, and tarts. While there is not a universal standard regarding taste, birthday cakes are often vanilla-, chocolate-, or strawberry-flavored. They are also baked in a variety of shapes and decorated in one color or multiple colors with icing or fondant.</p>
          <div class="view-buttn mt-lg-5 mt-md-4 mt-3">
            <!-- <a href="single.html" class="btn">Read More </a> -->
          </div>
        </div>
        <div class="col-lg-4 col-md-4 collective-images position-relative">
          <img src="admin/images/bb1.jpg" alt="news image" class="img-fluid">
          <div class="position-top-img">
            <img src="admin/images/bb3.jpg" alt="news image" class="img-fluid">
          </div>
        </div>
        <div class="col-lg-3 col-md-3 title-right-side my-3">
          <div class="rotated-title">
            <h3 class="title mb-lg-4 mb-md-3 mb-2">New Menu</h3>
            <h6 class="title-sub">Awesome Taste</h6>
          </div>
        </div>
      </div>
      <!--// row -->
      <!-- row -->
      <div class="row mid-row-grids">
        <div class="col-lg-5 col-md-6 collective-images my-3">
          <img src="admin/images/bb1.jpg" alt="news image" class="img-fluid">
        </div>
        <div class="col-lg-7 col-md-6 collection-w3layouts my-3">
          <h4>Event Cake</h4>
          <p class="mt-2">We Use Natural Ingredients In Our Cakes and Create Visual Works Of Art. We Introduce New Designs That Are Frequently Featured In Magazines. Call Us! Call for more information. Call Today For More Info. Types: Weddings, Birthdays, Baby showers, Grooms cakes.</p>
          <div class="view-buttn mt-lg-5 mt-md-4 mt-3">
            <!-- <a href="single.html" class="btn">Read More </a> -->
          </div>
        </div>

      </div>
      <!--// row -->
      <!-- row -->
      <div class="row">
        <div class="col-lg-6 col-md-5 collection-w3layouts my-3">
          <h4> Wedding Cake</h4>
          <p class="mt-2">A wedding cake is the traditional cake served at wedding receptions following dinner. In some parts of England, the wedding cake is served at a wedding breakfast; the 'wedding breakfast' does not mean the meal will be held in the morning, but at a time following the ceremony on the same day. In modern Western culture, the cake is usually on display and served to guests at the reception. Traditionally, wedding cakes were made to bring good luck to all guests and the couple. Modernly however, they are more of a centerpiece to the wedding and are not always even served to the guests. Some cakes are built with only a single edible tier for the bride and groom to share, but this is rare since the cost difference between fake and real tiers is minimal.</p>
          <div class="view-buttn mt-lg-5 mt-md-4 mt-3">
            <!-- <a href="single.html" class="btn">Read More </a> -->
          </div>
        </div>
        <div class="col-lg-3 col-md-4 collective-images my-3">
          <img src="admin/images/bb1.jpg" alt="news image" class="img-fluid">
        </div>
        <div class="position-top-three col-md-3 my-3">
          <img src="admin/images/bb3.jpg" alt="news image" class="img-fluid">
        </div>
      </div>
      <!--// row -->
    </div>
  </section>
  <!--//menu -->
  <!-- client -->
  <!-- <section class="client py-lg-4 py-md-3 py-sm-3 py-3" id="client">
    <div class="container py-lg-5 py-md-4 py-sm-4 py-3">
      <div class="row">
        <div class="col-lg-3 col-md-6 col-sm-6 cilent-item text-center my-3">
          <div class="clients-ile-img">
            <img src="admin/images/cc2.jpg" alt=" " class="img-fluid">
            <div class="clients-color-ile text-center mt-lg-4 mt-3">
              <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit Lorem ipsum dolor sit amet
              </p>
              <div class="mt-3 clients-txt-ile">
                <h4>Jack Will</h4>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 cilent-item text-center my-3">
          <div class="clients-ile-img">
            <img src="admin/images/cc1.jpg" alt=" " class="img-fluid">
            <div class="clients-color-ile text-center mt-lg-4 mt-3">
              <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit Lorem ipsum dolor sit amet
              </p>
              <div class="mt-3 clients-txt-ile">
                <h4>Sam Deo</h4>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 cilent-item text-center my-3">
          <div class="clients-ile-img">
            <img src="admin/images/cc2.jpg" alt=" " class="img-fluid">
            <div class="clients-color-ile text-center mt-lg-4 mt-3">
              <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit Lorem ipsum dolor sit amet
              </p>
              <div class="mt-3 clients-txt-ile">
                <h4>Max Rox</h4>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 title-right-side my-3">
          <div class="rotated-title">
            <h3 class="title mb-lg-4 mb-md-3 mb-2">Clients</h3>
            <h6 class="title-sub">Some Words</h6>
          </div>
        </div>
      </div>
    </div>
  </section> -->
  <!--//client -->
  <!-- footer -->
  <!-- <section class="py-lg-4 py-md-3 py-sm-3 py-3 bottom-footers">
    <div class="container py-lg-5 py-md-5 py-sm-4 py-3">
      <div class="row">
        <div class="col-lg-3 col-md-6 col-sm-6 bottom-footer-left">
          <div class="social-icons mb-lg-4 mb-3">
            <ul>
              <li class="facebook">
                <a href="#">
                  <span class="fa fa-facebook"></span>
                </a>
              </li>
              <li class="twitter">
                <a href="#">
                  <span class="fa fa-twitter"></span>
                </a>
              </li>
              <li class="rss">
                <a href="#">
                  <span class="fa fa-rss"></span>
                </a>
              </li>
            </ul>
          </div>
          <p>Lorem ipsum dolor sit amet consectetuer adipiscing elit Lorem ipsum dolor sit amet consectetuer </p>
          <div class="footer-w3layouts-head mt-2">
            <h2>
              <a href="index.html">Gateau</a>
            </h2>
          </div>
        </div>
        <div class="footer-info-bottom col-lg-3 col-md-6 col-sm-6 text-center">
          <h4 class="pb-lg-4 pb-md-3 pb-3">Nav Links</h4>
          <ul class="bottom-menu">
            <li class="py-sm-2 py-1">
              <a href="index.html">Home</a>
            </li>
            <li class="py-sm-2 py-1">
              <a href="about.html">About</a>
            </li>
            <li class="py-sm-2 py-1">
              <a href="service.html">Service</a>
            </li>
            <li class="py-sm-2 py-1">
              <a href="gallery.html">Gallery</a>
            </li>
            <li>
              <a href="contact.html">Contact</a>
            </li>
          </ul>
        </div>
        <div class="footer-info-bottom col-lg-3 col-md-6 col-sm-6 col-sm-6 text-center">
          <h4 class="pb-lg-4 pb-md-3 pb-3">Twitter Us</h4>
          <div class="footer-office-hour">
            <ul>
              <li>
                <p>sit amet consectetur adipiscing</p>
              </li>
              <li class="my-1">
                <p>
                  <a href="mailto:info@example.com">info@example.com</a>
                </p>
              </li>
              <li class=" mb-sm-3 mb-2">
                <span>Posted 3 days ago.</span>
              </li>
              <li>
                <p>sit amet consectetur adipiscing</p>
              </li>
              <li class="my-1">
                <p>
                  <a href="mailto:info@example.com">info@example.com</a>
                </p>
              </li>
              <li>
                <span>Posted 3 days ago.</span>
              </li>
            </ul>
          </div>
        </div>
        <div class="footer-info-bottom col-lg-3 col-md-6 col-sm-6 text-center">
          <h4 class="pb-lg-4 pb-md-3 pb-3">NewsLetter</h4>
          <div class="newsletter-footers">
            <form action="#" method="post">
              <input type="email" name="Your Email" class="form-control" placeholder="Your Email" required="">
              <button type="submit" class="btn1 mt-3">SubScribe</button>
            </form>
          </div>
          <div class="footer-office-hour mt-sm-3 mt-2">
            <p>vehicula velit sagittis vehicula. Duis posuere ex in mollis iaculis. Suspendisse tincidunt velit</p>
          </div>
        </div>
      </div> -->
      <!-- move icon -->
      <div class="text-center">
        <a href="#home" class="move-top text-center mt-3">
          <i class="fa fa-arrow-up" aria-hidden="true"></i>
        </a>
      </div>
      <!--//move icon -->
    </div>
  </section>
  <footer>
    <div class="bottem-wthree-footer text-center py-md-4 py-3">
      <p>
        © 2019 Bakery. All Rights Reserved | Design by
        <a href="#" target="_blank">Bency Cheriyan</a>
      </p>
    </div>
  </footer>
  <!--//footer -->
</body>

</html>
<?php endif; ?>