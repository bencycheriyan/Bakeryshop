@if(session()->has('email'))
<!DOCTYPE html>
<html lang="zxx">

<head>
  <title>Bakery</title>
  <!--meta tags -->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="keywords" content="Gateau Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
      Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
  
<script>
  function isNumberKey(evt)
  {
    var charCode=(evt.which)?evt.which:event.KeyCode;
    if(charCode!=46 && charCode>31 && (charCode<48||charCode>57))
    {
      alert("Enter Number");
      return false;
      }
      return true;
      }
    function lettersOnly() 
{
            var charCode = event.keyCode;

            if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || charCode == 8)

                return true;
            else
      alert("Enter chararctes only");
                return false;
}
</script>


  <script>
    addEventListener("load", function () {
      setTimeout(hideURLbar, 0);
    }, false);

    function hideURLbar() {
      window.scrollTo(0, 1);
    }
  </script>
  <!--//meta tags ends here-->
  <!--booststrap-->
  <link href="admin/css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
  <!--//booststrap end-->
  <!-- font-awesome icons -->
  <link href="admin/css/font-awesome.min.css" rel="stylesheet">
  <!-- //font-awesome icons -->
  <!--stylesheets-->
  <link href="admin/css/style.css" rel='stylesheet' type='text/css' media="all">
  <!--//stylesheets-->
  <link href="//admin/fonts.googleapis.com/css?family=Arimo:400,700" rel="stylesheet">
  <link href="//admin/fonts.googleapis.com/css?family=Roboto:400,500,700,900" rel="stylesheet">

  <style>
                                        #customers {
                                            font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
                                            border-collapse: collapse;
                                            width: 70%;

                                        }

                                        #customers td, #customers th {
                                            border: 1px solid #ddd;
                                            padding: 8px;
                                        }

                                        #customers tr:nth-child(even){background-color: #f2f2f2;}

                                        #customers tr:hover {background-color: #ddd;}

                                        #customers th {
                                            padding-top: 12px;
                                            padding-bottom: 12px;
                                            text-align: left;
                                            background-color: #f093bf;
                                            color: white;
                                        }
                                      </style>
</head>

<body>
  <!--headder-->
  <div class="header-outs inner_page-banner " id="home">
    <div class="headder-top">
      <!-- nav -->
      <nav>
        <div id="logo">
          <h1>
            <a href="adminindex">Bakery</a>
            <h6>{{session()->get('email')}}</h6>
          </h1>
        </div>
        <label for="drop" class="toggle">Menu</label>
        <input type="checkbox" id="drop">
        <ul class="menu mt-2">
          <li class="active">
            <a href="admin.adminindex">Home</a>
          </li>
          <!-- <li class="mx-lg-3 mx-md-2 my-md-0 my-1">
            <a href="addproduct">About</a>
          </li> -->
          <!-- <li>
            <a href="service.html">Services</a>
          </li> -->
          <li class="mx-lg-3 mx-md-2 my-md-0 my-1">
            <!-- First Tier Drop Down -->
            <label for="drop-2" class="toggle toogle-2">Pages
              <span class="fa fa-angle-down" aria-hidden="true"></span>
            </label>
             <a href="#">Pages
              <span class="fa fa-angle-down" aria-hidden="true"></span>
            </a> 
            <input type="checkbox" id="drop-2">
            <ul>
              <li>
                <a href="/allcustomer" class="drop-text">Customers</a>
              </li>
              <!-- <li>
                <a href="/allshopowner" class="drop-text">Shopowners</a>
              </li> -->
              <li>
                <a href="/addcategory" class="drop-text">Add Category</a>
              </li>
              <li>
                <a href="/additem" class="drop-text">Add subcategory</a>
              </li>
              <li>
                <a href="/addproduct" class="drop-text">Add Product</a>
              </li>
              <li>
                <a href="/viewproduct" class="drop-text">view Product</a>
              </li>
              <!-- <li>
                <a href="/addrecipie" class="drop-text">Add Recipie</a>
              </li> -->
            </ul>
          </li>
          <li class="mx-lg-3 mx-md-2 my-md-0 my-1">

        <label for="drop-2" class="toggle toogle-2">Views
              <span class="fa fa-angle-down" aria-hidden="true"></span>
        </label>
                 <a href="#">Views
                 <span class="fa fa-angle-down" aria-hidden="true"></span>
                 </a>
                 <input type="checkbox" id="drop-2">
            <ul>
               <li>
                <a href="/category" class="drop-text">Category</a>
              </li>
              <li>
                <a href="/item" class="drop-text">SubCategory</a>
              </li>
              <!-- <li>
                <a href="/blocked" class="drop-text">Blocked Users</a>
              </li> -->
              <li>
                <a href="/bookdetails" class="drop-text">Booking History</a>
              </li>
              
            </ul>
    </li>
          <li>
            <a href="/logout">Logout</a>
          </li>
        </ul>
      </nav>
      <!-- //nav -->
    </div>
</div>
<br>

<div class="table">
      <table id="customers" align="center">
                    <tr>
                      <th>SL No.</th>
                      <th>Category</th>
                      <th>SubCategory</th>
                    </tr>


                           <?php 
                           $count=1; 
                           ?>



                    @isset($a)  
                  @foreach ($a as $data)

              <tr>
                <td>{{$count++}}</td>
                <td>{{$data->category}}</td>
                <td>{{$data->item}}</td>
              </tr>
             @endforeach
             @endisset
              </table>
             </div>

<br>

<section class="py-lg-4 py-md-3 py-sm-3 py-3 bottom-footers">
    <div class="container py-lg-5 py-md-5 py-sm-4 py-3">
      <div class="row">
        <div class="col-lg-3 col-md-6 col-sm-6 bottom-footer-left">
          <div class="social-icons mb-lg-4 mb-3">
            <ul>
              <li class="facebook">
                <a href="#">
                  <span class="fa fa-facebook"></span>
                </a>
              </li>
              <li class="twitter">
                <a href="#">
                  <span class="fa fa-twitter"></span>
                </a>
              </li>
              <li class="rss">
                <a href="#">
                  <span class="fa fa-rss"></span>
                </a>
              </li>
            </ul>
          </div>
          <p>Lorem ipsum dolor sit amet consectetuer adipiscing elit Lorem ipsum dolor sit amet consectetuer </p>
          <div class="footer-w3layouts-head mt-2">
            <h2>
              <a href="index.html">Bakery</a>
            </h2>
          </div>
        </div>
        <div class="footer-info-bottom col-lg-3 col-md-6 col-sm-6 text-center">
          <h4 class="pb-lg-4 pb-md-3 pb-3">Nav Links</h4>
          <ul class="bottom-menu">
            <li class="py-2">
              <a href="adminindex">Home</a>
            </li>
            <li class="py-2">
              <a href="about.html">About</a>
            </li>
            <li class="py-2">
              <a href="service.html">Service</a>
            </li>
            <li class="py-2">
              <a href="gallery.html">Gallery</a>
            </li>
            <li>
              <a href="contact.html">Contact</a>
            </li>
          </ul>
        </div>
        <div class="footer-info-bottom col-lg-3 col-md-6 col-sm-6 col-sm-6 ">
          <h4 class="pb-lg-4 pb-md-3 pb-3">Twitter Us</h4>
          <div class="footer-office-hour">
            <ul>
              <li>
                <p>sit amet consectetur adipiscing</p>
              </li>
              <li class="my-1">
                <p>
                  <a href="mailto:info@example.com">info@example.com</a>
                </p>
              </li>
              <li class="mb-3">
                <span>Posted 3 days ago.</span>
              </li>
              <li>
                <p>sit amet consectetur adipiscing</p>
              </li>
              <li class="my-1">
                <p>
                  <a href="mailto:info@example.com">info@example.com</a>
                </p>
              </li>
              <li>
                <span>Posted 3 days ago.</span>
              </li>
            </ul>
          </div>
        </div>
        <div class="footer-info-bottom col-lg-3 col-md-6 col-sm-6 ">
          <h4 class="pb-lg-4 pb-md-3 pb-3">NewsLetter</h4>
          <div class="newsletter-footers">
            <form action="#" method="post">
              <input type="email" name="Your Email" class="form-control" placeholder="Your Email" required="">
              <button type="submit" class="btn1 mt-3">SubScride</button>
            </form>
          </div>
          <div class="footer-office-hour mt-3">
            <p>vehicula velit sagittis vehicula. Duis posuere ex in mollis iaculis. Suspendisse tincidunt velit</p>
          </div>
        </div>
      </div>
      <!-- move icon -->
      <div class="text-center">
        <a href="#home" class="move-top text-center mt-3">
          <i class="fa fa-arrow-up" aria-hidden="true"></i>
        </a>
      </div>
      <!--//move icon -->
    </div>
  </section>
  <footer>
    <div class="bottem-wthree-footer text-center py-md-4 py-3">
      <p>
        © 2019 Bakery. All Rights Reserved | Design by
        <a href="" target="_blank">Bency Cheriyan</a>
      </p>
    </div>
  </footer>
  <!--//footer -->
</body>

</html>
@endif