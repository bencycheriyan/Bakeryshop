









<div style="background-color: white;width: 700px;height: 600px;border: 2px solid white;padding-left: 15px;margin: 400px;margin-top:50px;">
    <h1 align="center"><b><font color="#dc3545">Edit Profile</font></b></h1><br><br>


    @foreach($value as $value)
    <form method="post" action="{{route('shopowner.editprofile',$value->email)}}">
      @csrf
<center><table border=0>
<tr><th class="form-control">First Name</th><td><input type="text" class="form-control" name="firstname" value={{$value->firstname}}/></td></tr>

<tr><th class="form-control">Last Name </th><td><input type="text" class="form-control" name="lastname" value={{$value->lastname}}/></td></tr>

<tr><th class="form-control">Phone Number</th><td><input type="text" class="form-control" name="phoneno" value={{$value->phoneno}}/></td></tr>



<tr><th class="form-control">Email Id</th><td><input type="text" class="form-control" name="email" value={{$value->email}}/></td></tr>


<tr><th><input style="background-color:#438eb9;text-decoration:none;color:white;margin-left:150px;margin-top:50px;" type="submit" name="update" value="update"/></th></tr>
<!-- <input type= "hidden" value="" name="" /> -->
</table></center>
</form>
@endforeach
</center>
</div>


